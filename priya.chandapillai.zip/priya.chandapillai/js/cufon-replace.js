Cufon.replace('h2, h3', { fontFamily: 'Bebas', hover:true });
Cufon.replace('#menu a', { fontFamily: 'Bebas', hover:true, textShadow:'rgba(0,0,0,.4) 1px 1px 2px' });

